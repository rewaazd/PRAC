let name = prompt("Ваше имя:");
let surname = prompt("Ваш возраст:");

alert(`Привет, ${name} ${surname} `);

console.log(name, surname);


let age = prompt('Введите ваш возраст:');

if (age >= 18) {
    alert('Вы совершеннолетний');
}   else {
    alert('Вы несовершеннолетний');
}

let number = Math.floor(Math.random() * 10) + 1;

let numberuser = prompt('Угадайте число')

if (numberuser == number){
    alert('Вы угадали число!');
}   else {
    if (numberuser <5) {
        alert('Загаданное число меньше 5');
    } else {
        alert('Загаданное число больше 5');
    }
}


let passworduser = prompt('Введите пароль из 5 цифр');


if ((passworduser || passworduser.trim() == "") || (passworduser < 10000 && passworduser > 99999)) {
    alert('Пароль пустой или содержит меньше 5 символов, введите ещё раз');
    let passworduser = prompt('Введите пароль из 5 цифр');
}


let password = Math.floor(10000 + Math.random() * 90000);

if (passworduser == password){
    alert('Доступ разрешён');
} else {
    alert('Доступ запрещён');
}

let fnum = Number(prompt('Введите первое число: '));
let snum = Number(prompt('Введите второе число: '));
let oper = prompt('Введите оператор: ');

if ((oper === "+") || (oper === "-") || (oper === "*") || (oper === "/")) {
    if (oper === '+') {
        alert(fnum + snum);
    }
    if (oper === '-') {
        alert(fnum - snum);
    }

    if (oper === '*') {
        alert(fnum * snum);
    }

    if (oper === '/') {
        alert(fnum / snum);
    }
} else {
    alert("Некорректный оператор. Попробуйте еще раз.");
    let oper = prompt('Введите оператор');
    if (oper === '+') {
        alert(fnum + snum);
    }
    if (oper === '-') {
        alert(fnum - snum);
    }

    if (oper === '*') {
        alert(fnum * snum);
    }

    if (oper === '/') {
        alert(fnum / snum);
    }
}


