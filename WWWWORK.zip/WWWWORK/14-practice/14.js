const header = document.querySelector('h1');


header.addEventListener('mouseover', () =>{
    header.style.fontSize = "25pt";
});
header.addEventListener('mouseout', () =>{
    header.style.fontSize = "20pt";
});






const img = document.querySelector('img');
img.addEventListener('mouseover', () => {
    img.animate(
    [
        { transform: 'rotate(0deg)' },
        { transform: 'rotate(360deg)' }
    ],
    {
        duration: 1500,  
        iterations: 1,  
        easing: 'ease'   
    }
    );
});

const paragraph = document.querySelector('p');
paragraph.addEventListener('click', () =>{
    paragraph.style.color = 'purple';
});


const btn = document.getElementById('MyBtn');
const table = document.querySelector('table');

btn.addEventListener('click', () =>{
    
    if (table.classList.contains("visually-hidden")){
        table.classList.remove("visually-hidden");
        btn.textContent = "Скрыть лекции";
        setTimeout(() => {
            table.style.opacity = "1";
        }, 0)
    }else{
        table.style.opacity = "0";
        btn.textContent = "Показать лекции";
        setTimeout(() => {
            table.classList.add("visually-hidden");
        }, 250)
    }
});


document.getElementById("myForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const message = document.getElementById("message");
    message.classList.add("show");
});