
// 1

const heading1 = document.querySelector("h1");
heading1.textContent = "Добро пожаловать на наш сайт!";

const heading2 = document.querySelector("h2");
heading2.style.color = ("Red");

heading1.textContent = "Это новый текст параграфа";

const video = document.querySelector(".video");
video.style.display = ("none");

// 2

let formData = {
    username: "",
    email: "",
    phone: "",
    date: "",
    comment: "",

    printData: function() {
      console.log(`Имя: ${this.username}`);
      console.log(`E-mail: ${this.email}`);
      console.log(`Телефон: ${this.phone}`);
      console.log(`Дата: ${this.date}`);
      console.log(`Комментарий: ${this.comment}`);
    }
};

function submitForm(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const date = document.getElementById('date').value;
    const comment = document.getElementById('comment').value;

    // Проверка
    if (!username || !email || !comment) {
      alert("Имя, E-mail и комментарий не могут быть пустыми.");
      return;
    }

    if (!/^\d+$/.test(phone)) {
      alert("Телефон должен содержать только цифры.");
      return;
    }

    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailRegex.test(email)) {
      alert("Некорректный E-mail.");
      return;
    }

    formData.username = username;
    formData.email = email;
    formData.phone = phone;
    formData.date = date;
    formData.comment = comment;

    formData.printData();
}
  
document.getElementById('myForm').addEventListener('submit', submitForm);