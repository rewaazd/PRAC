// 1
let name = "Alex";
let surname = "Chirkov";
let age = 19;

if (age >=18) {
    alert('Вы совершеннолетний');
} else {
    alert('Вы несовершеннолетний');
}

// 2

for (let i = 1; i <= 10; i++) {
    console.log(i);
}

let i = 10;
while (i >= 1) {
    console.log(i);
    i--;
}

// 3

const lect = ['Theme 1', 'OTheme 2', 'Theme 3'];
const lecrt = ['Theme 1', 'OTheme 2', 'Theme 3'];
const prac = ['Prac 1', 'Prac 2', 'Prac 3'];

lect.push('OTheme 4');
prac.unshift('Prac 0');



function prin2t() {
    lect.forEach(function(i) {
        console.log(i);
    });
    
    prac.forEach(function(i) {
        console.log(i);
    });
}

prin2t();

// 4

function prov() {
    for (let i = 0; i < lect.length; i++) {
        if (lect[i][0] != 'O') {
            lect.splice(i,1)
        }
    }
    console.log(lect);
    console.log(prac);
};

prov();
