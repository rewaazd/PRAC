const header = document.querySelector('h1');
const image = document.getElementById('image');
document.getElementById('btn1').onclick = MyFunction;




header.addEventListener('click', () =>{
    header.textContent = "Вы кликнули на заголовок - так держать!";
});

image.addEventListener('mouseover', () =>{
    image.style.width = "225px";
    image.style.height = "225px";
});
image.addEventListener('mouseout', () =>{
    image.style.width = "200px";
    image.style.height = "200px";
});

image.addEventListener('click', () =>{
    image.setAttribute('src', '23.png');
});
image.addEventListener('dblclick', () =>{
    alert('Эй, расслабься');
});

function MyFunction(){

    const rows = document.querySelectorAll('tr');

    let SecondSemestr = ['Базовое бэкенд-приложение', 
                        'HTTP-запросы', 'JSON и работа с ним',
                        'HTTP-ответы', 'Проектирование API',
                        'Роутинг и его настройка', ' NoSQL базы данных',
                        'Обеспечение авторизации и доступа пользователей', 'Работа сторонних сервисов уведомления и авторизации',
                        'Основы ReactJS', 'Работа с компонентами динамической DOM',
                        'Использование хуков в React', 'Основы микросервисной архитектуры',
                        'Разработка классических модулей веб-приложений', 'Разработка классических модулей веб-приложений',
                        'Разработка классических модулей веб-приложений']

    for(i=1; i<rows.length; i++){
        let val = rows[i].cells[1];
        val.textContent = SecondSemestr[i-1];
    }

}